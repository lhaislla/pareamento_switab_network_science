# SWITAB — Dashboard Interativo

Aplicação Dash organizada em módulos para análise de **Pareamento** e **Comunidades** na rede SWITAB.

## Estrutura do Projeto

```text
switab_dashboard/
├── .env                          # Variáveis de ambiente locais
├── .env.example                  # Modelo de variáveis de ambiente
├── requirements.txt              # Dependências Python
├── app.py                        # Inicialização do app Dash e registro de callbacks
├── config/
│   ├── __init__.py
│   └── settings.py               # Leitura e validação de configurações (.env)
├── core/
│   ├── __init__.py
│   ├── pareamento_engine.py      # Ingestão, afinidade, algoritmos e métricas de pareamento
│   └── comunidades_engine.py     # Grafos, detecção de comunidades e métricas topológicas
├── viz/
│   ├── __init__.py
│   ├── graficos_pareamento.py    # Gráficos Plotly de similaridade e bipartido
│   └── graficos_comunidades.py   # Gráficos Plotly de redes e comunidades
├── components/
│   ├── __init__.py
│   └── cards.py                  # Cards de métricas e síntese textual complementar
├── pages/
│   ├── __init__.py
│   ├── pareamento_page.py        # Layout do painel Pareamento
│   └── comunidades_page.py       # Layout do painel Comunidades
└── data/                         # Bases de dados CSV/Excel (opcional; fallback sintético)
```

## Execução

```bash
pip install -r requirements.txt
python app.py
```
